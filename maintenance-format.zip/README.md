# Formato de Mantenimiento Correctivo

Este repositorio contiene una página HTML lista para usar como formato de mantenimiento correctivo de equipos de cómputo.

## Archivos

- **index.html**: Formato con 5 fallas simuladas y descripción de procesos.
- **README.md**: Este archivo con explicación e instrucciones.
- **.gitignore**: Ignora archivos temporales comunes.

## Cómo usar

1. Clona o descarga este repositorio.
2. Abre `index.html` en tu navegador o edítalo con tu IDE preferido.
3. Modifica las filas de la tabla y los datos según tus necesidades.
4. Sube los cambios a GitHub con `git add`, `git commit` y `git push`.

## Licencia

MIT
